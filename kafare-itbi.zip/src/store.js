import Vue from "vue"
import Vuex from "vuex"

const state = {
    specials: [{
            image: "/img/special-1.jpg",
            text: "เทศกาลแห่งความรักสั่งกลับบ้านลด 50%"
        },
        {
            image: "/img/special-2.jpg",
            text: "สั่งแพ็คคู่ เครื่องดื่ม+ของหวาน ลด 20%"
        },
        {
            image: "/img/special-3.jpg",
            text: "สั่งสเปเชียลเมนูทุกวันพุธ 30%"
        }
    ],
    menus: [{
            image: "./img/menu-1.jpg",
            text: "ม็อคค่า",
            price: 50,
            love: false
        },
        {
            image: "./img/menu-2.jpg",
            text: "อเมริกาโน",
            price: 40,
            love: false
        },
        {
            image: "./img/menu-3.jpg",
            text: "ลาเต้",
            price: 50,
            love: true
        },
        {
            image: "./img/menu-4.jpg",
            text: "เวียนนาคอฟฟี",
            price: 55,
            love: false
        },
        {
            image: "./img/menu-5.jpg",
            text: "คาปูชิโน",
            price: 45,
            love: false
        },
        {
            image: "./img/menu-5.jpg",
            text: "เอสเพรซโซ",
            price: 40,
            love: false
        }

    ]
};

const getters = {
    specials(state) {
        return state.specials;
    },
    menus(state) {
        return state.menus;
    }
}

Vue.use(Vuex);

const store = new Vuex.Store({
    state,
    getters
})

export default store;