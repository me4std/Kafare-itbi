<template>
  <v-app>
    <v-app-bar app color="deep-purple accent-4" dark>
      <v-icon class="mr-5">mdi-coffee-outline</v-icon>
      <v-toolbar-title>Kafare-ITBI</v-toolbar-title>

      <v-spacer></v-spacer>

      <v-menu>
        <template v-slot:activator="{ on }">
          <v-btn icon v-on="on"> 
            <v-icon>mdi-menu</v-icon>
          </v-btn>
        </template>

        <v-list>
          <v-list-item>
            <v-list-item-title>โปรไฟล์</v-list-item-title>
          </v-list-item>
          <v-divider></v-divider>
          <v-list-item>
            <v-list-item-title class="red--text">ออกจากระบบ</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
      
    </v-app-bar>

    <v-content>
      <router-view></router-view>
    </v-content>
   
  </v-app>
</template>

<script>

export default {
  name: 'App',

  components: {

  },

  data: () => ({
    //
  }),
};

</script>

<style lang="scss" scoped>
.v-application {
  font-family: "kanit";
}
</style>
